<?php $__env->startSection('content'); ?>
    hello matrix
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\golden-sweeft-maher\resources\views/admin/pages/dashboard.blade.php ENDPATH**/ ?>